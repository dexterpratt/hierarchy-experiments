# -*- coding: utf-8 -*-

__author__ = 'Chris Churas'
__email__ = 'churas.camera@gmail.com'
__version__ = '0.1.0'

from .cd import CommunityDetectionError
from .cd import CommunityDetection
